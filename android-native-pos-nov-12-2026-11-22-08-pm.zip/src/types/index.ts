/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: number;
  store_name: string;
  owner_name: string;
  phone: string;
  password: string;
  governorate: string;
  district: string;
  neighborhood: string;
  pin_code: string;
  subscription_end: number;
  role: 'owner' | 'merchant' | 'cashier';
  status: 'active' | 'suspended';
  suspension_reason?: string | null;
  subscription_price?: number;
}

export interface SubscriptionPackage {
  id: number;
  name: string;
  duration_days: number;
  price: number;
  description?: string;
  is_active: number; // 1 = active, 0 = inactive
}

export interface Product {
  id: number;
  store_id: number;
  name: string;
  barcode: string;
  unit_type: 'قطعة' | 'كرتون' | 'كيلو';
  category?: string;
  cost_price: number;
  sale_price: number;
  quantity: number;
  min_stock: number;
  expiry_date?: string;
  is_active: number; // 1 = active, 0 = inactive
}

export interface Customer {
  id: number;
  store_id: number;
  name: string;
  phone: string;
  total_debt: number;
  credit_limit?: number; // سقف الدين المسموح
}

export interface Sale {
  id: number;
  store_id: number;
  customer_id: number | null;
  customer_name?: string;
  total_amount: number;
  discount_amount?: number;
  paid_amount: number;
  remaining_amount: number;
  payment_type: 'نقداً' | 'آجل' | 'شبكة';
  created_at: string;
}

export interface ParkedSale {
  id: string;
  store_id: number;
  cart: CartItem[];
  customer_name?: string;
  customer_id?: number | null;
  discount: number;
  created_at: string;
}

export interface SaleItem {
  id: number;
  sale_id: number;
  product_id: number;
  product_name?: string;
  qty: number;
  price: number;
}

export interface ReturnItem {
  id: number;
  store_id: number;
  sale_id: number | null;
  customer_id: number | null;
  product_id: number;
  qty: number;
  amount: number;
  type: 'invoice' | 'credit';
  created_at: string;
}

export interface CartItem {
  product: Product;
  qty: number;
  price: number;
  subtotal: number;
}

export interface SharedPreferences {
  user_id: number | null;
  store_id: number | null;
  status: 'active' | 'suspended';
  is_suspended_flag?: boolean;
  biometric_enabled?: boolean;
  current_pin?: string;
  dark_mode?: boolean;
}
