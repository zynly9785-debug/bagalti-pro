/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Store, Phone, Lock, Sparkles, Key, AlertCircle } from 'lucide-react';
import { db } from '../../../db/sqlite-simulation.ts';
import { checkSecretTaps } from '../../../utils/pureLogic.ts';
import { useTheme } from '../../../context/ThemeContext.tsx';

interface LoginScreenProps {
  onNavigate: (screen: string, params?: Record<string, unknown>) => void;
  onOpenOwnerDoor: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onNavigate, onOpenOwnerDoor }) => {
  const { isDarkMode, theme } = useTheme();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [tapTimestamps, setTapTimestamps] = useState<number[]>([]);

  // Stealth 10-tap secret detection on the logo (no visual feedback, no counter)
  const handleLogoClick = () => {
    const now = Date.now();
    const newTaps = [...tapTimestamps, now];
    setTapTimestamps(newTaps);

    const isSecretTriggered = checkSecretTaps(newTaps, 500, 10);
    if (isSecretTriggered) {
      setTapTimestamps([]);
      onOpenOwnerDoor();
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const user = db.findUserByPhoneAndPassword(phone, password);
    if (!user) {
      setError('رقم الهاتف أو كلمة المرور غير صحيحة');
      return;
    }

    const isSuspended = user.status === 'suspended';
    db.saveSharedPreferences({
      user_id: user.id,
      store_id: user.id,
      status: user.status,
      is_suspended_flag: isSuspended,
    });

    onNavigate('dashboard', {
      isSuspended,
      suspension_reason: user.suspension_reason,
      storeName: user.store_name,
    });
  };

  return (
    <div className={`flex-1 flex flex-col justify-between p-6 overflow-y-auto transition-colors duration-300 ${theme.screenBg}`}>
      {/* Top Branding Section */}
      <div className="flex flex-col items-center pt-6 text-center">
        {/* Stealth Logo with silent 10-taps detector */}
        <div className="mb-3 select-none">
          <div
            onClick={handleLogoClick}
            role="button"
            tabIndex={-1}
            className="w-20 h-20 rounded-2xl bg-[#0B3D2E] text-[#C9A961] shadow-lg flex items-center justify-center border-2 border-[#C9A961]/40 cursor-default select-none outline-none"
          >
            <Store className="w-10 h-10 pointer-events-none" />
          </div>
        </div>

        <h1 className={`text-xl font-bold ${isDarkMode ? 'text-white' : 'text-[#0B3D2E]'}`}>بقالتي برو (Grocery POS)</h1>
        <p className={`text-xs mt-0.5 ${theme.textSecondary}`}>نظام إدارة المبيعات والمخزون والديون</p>
      </div>

      {/* Login Card (CardView) */}
      <div className={`rounded-2xl p-5 shadow-md border my-4 transition-colors duration-300 ${theme.cardBg}`}>
        <form onSubmit={handleLogin} className="space-y-3.5">
          <div>
            <label className={`block text-xs font-bold mb-1 ${theme.textSecondary}`}>
              رقم الهاتف:
            </label>
            <div className="relative">
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="أدخل رقم هاتفك..."
                dir="ltr"
                className={`w-full text-right rounded-xl px-3 py-2.5 pl-9 text-xs font-semibold focus:outline-none border ${theme.inputBg}`}
                required
              />
              <Phone className="w-4 h-4 text-[#C9A961] absolute left-3 top-3" />
            </div>
          </div>

          <div>
            <label className={`block text-xs font-bold mb-1 ${theme.textSecondary}`}>
              كلمة المرور:
            </label>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="أدخل كلمة المرور..."
                dir="ltr"
                className={`w-full text-right rounded-xl px-3 py-2.5 pl-9 text-xs font-semibold focus:outline-none border ${theme.inputBg}`}
                required
              />
              <Lock className="w-4 h-4 text-[#C9A961] absolute left-3 top-3" />
            </div>
          </div>

          {error && (
            <div className="flex items-center gap-1.5 p-2 bg-red-950/40 text-red-300 border border-red-800 rounded-xl text-xs font-semibold">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-[#0B3D2E] text-white py-3 rounded-xl font-bold text-xs hover:bg-[#06231A] active:scale-98 transition shadow-md flex items-center justify-center gap-2"
          >
            <span>دخول</span>
          </button>
        </form>
      </div>

      {/* Footer Registration Link */}
      <div className="text-center pb-2">
        <button
          type="button"
          onClick={() => onNavigate('register')}
          className="text-xs font-bold text-[#C9A961] hover:underline"
        >
          ليس لديك حساب؟ إنشاء حساب بقالة جديد مجاناً (تجربة 60 يوم)
        </button>
      </div>
    </div>
  );
};
