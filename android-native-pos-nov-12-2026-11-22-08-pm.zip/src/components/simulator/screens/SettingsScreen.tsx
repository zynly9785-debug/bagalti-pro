/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  ArrowRight,
  Store,
  Shield,
  Fingerprint,
  KeyRound,
  Download,
  Upload,
  Mail,
  PhoneCall,
  MessageSquare,
  Send,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Moon,
  Sun,
} from 'lucide-react';
import { db } from '../../../db/sqlite-simulation.ts';
import { getSubscriptionStatus } from '../../../utils/pureLogic.ts';
import { BiometricPromptModal } from '../BiometricPromptModal.tsx';
import { useTheme } from '../../../context/ThemeContext.tsx';
import JSZip from 'jszip';

interface SettingsScreenProps {
  storeId: number;
  onNavigate: (screen: string, params?: Record<string, unknown>) => void;
}

const SUPPORT_PHONE = '+967778228995';

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ storeId, onNavigate }) => {
  const { isDarkMode, toggleDarkMode, setDarkMode, theme } = useTheme();
  const [storeName, setStoreName] = useState('');
  const [governorate, setGovernorate] = useState('');
  const [pin, setPin] = useState('1234');
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [subscriptionEnd, setSubscriptionEnd] = useState(Date.now() + 60 * 24 * 60 * 60 * 1000);

  const [showBiometricModal, setShowBiometricModal] = useState(false);
  const [showPinModal, setShowPinModal] = useState(false);
  const [newPinInput, setNewPinInput] = useState('');
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    loadSettings();
  }, [storeId]);

  const loadSettings = () => {
    const user = db.findUserById(storeId);
    if (user) {
      setStoreName(user.store_name);
      setGovernorate(user.governorate);
      setPin(user.pin_code || '1234');
      setSubscriptionEnd(user.subscription_end);
    }
    const prefs = db.getSharedPreferences();
    setBiometricEnabled(!!prefs.biometric_enabled);
  };

  const handleUpdateStoreProfile = (e: React.FormEvent) => {
    e.preventDefault();
    db.updateUserProfile(storeId, {
      store_name: storeName.trim(),
      governorate: governorate.trim(),
    });
    setNotice('تم تحديث بيانات المتجر بنجاح!');
    setTimeout(() => setNotice(null), 3000);
  };

  const handleBiometricToggle = () => {
    if (!biometricEnabled) {
      setShowBiometricModal(true);
    } else {
      setBiometricEnabled(false);
      db.saveSharedPreferences({ biometric_enabled: false });
    }
  };

  const handleBiometricSuccess = () => {
    setShowBiometricModal(false);
    setBiometricEnabled(true);
    db.saveSharedPreferences({ biometric_enabled: true });
    setNotice('تم تفعيل الحماية بالبصمة البيومترية بنجاح!');
    setTimeout(() => setNotice(null), 3000);
  };

  const handleChangePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPinInput.trim().length >= 4) {
      db.updateUserProfile(storeId, { pin_code: newPinInput.trim() });
      db.saveSharedPreferences({ current_pin: newPinInput.trim() });
      setPin(newPinInput.trim());
      setShowPinModal(false);
      setNewPinInput('');
      setNotice('تم تغيير رمز الأمان (PIN) بنجاح!');
      setTimeout(() => setNotice(null), 3000);
    }
  };

  // Backup SQLite database to Zip and trigger email action
  const handleBackupToEmail = async () => {
    try {
      const zip = new JSZip();
      const rawData = db.getRawState();
      zip.file('grocery_pos_database.json', JSON.stringify(rawData, null, 2));
      zip.file('schema_info.txt', 'SQLite Database Export for Grocery POS v1.0\nStore ID: ' + storeId);

      const content = await zip.generateAsync({ type: 'blob' });

      // Trigger download of zip
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `grocery_backup_store_${storeId}_${new Date().toISOString().split('T')[0]}.zip`;
      a.click();
      URL.revokeObjectURL(url);

      // Open Gmail simulation / intent
      const subject = encodeURIComponent('نسخة احتياطية لقاعدة بيانات بقالتي');
      const body = encodeURIComponent(
        'مرفق ملف النسخة الاحتياطية المضغوطة لتطبيق البقالة (grocery_backup.zip). احتفظ بها بأمان.'
      );
      window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');

      setNotice('تم تجهيز ملف النسخة الاحتياطية المضغوط (.zip) وفتح تطبيق البريد الإلكتروني!');
      setTimeout(() => setNotice(null), 4000);
    } catch {
      setNotice('حدث خطأ أثناء ضغط النسخة الاحتياطية');
    }
  };

  // Restore SQLite database from file
  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        // If it is JSON or extracted zip
        if (file.name.endsWith('.json')) {
          const parsed = JSON.parse(text);
          db.restoreFromRawState(parsed);
          setNotice('تم استرجاع قاعدة البيانات بنجاح!');
          loadSettings();
        } else if (file.name.endsWith('.zip')) {
          const zip = await JSZip.loadAsync(file);
          const jsonFile = zip.file('grocery_pos_database.json');
          if (jsonFile) {
            const jsonText = await jsonFile.async('text');
            const parsed = JSON.parse(jsonText);
            db.restoreFromRawState(parsed);
            setNotice('تم فك ضغط النسخة الاحتياطية واسترجاع قاعدة البيانات!');
            loadSettings();
          } else {
            setNotice('الملف المضغوط لا يحتوي على بيانات صالحة');
          }
        }
      } catch {
        setNotice('فشل قراءة ملف النسخة الاحتياطية');
      }
    };
    reader.readAsText(file);
  };

  const subStatus = getSubscriptionStatus(subscriptionEnd);
  const expiryDate = new Date(subscriptionEnd).toLocaleDateString('ar-YE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className={`flex-1 flex flex-col overflow-hidden transition-colors duration-300 ${theme.screenBg}`}>
      {/* Header */}
      <div className="bg-[#0B3D2E] text-white p-3.5 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('dashboard')}
            className="p-1 hover:bg-white/10 rounded-full"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
          <h2 className="font-bold text-sm">الإعدادات والمظهر والنسخ الاحتياطي</h2>
        </div>
        <Store className="w-5 h-5 text-[#C9A961]" />
      </div>

      {notice && (
        <div className="bg-emerald-700 text-white p-2.5 text-xs text-center font-bold flex items-center justify-center gap-1.5 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-[#C9A961]" />
          <span>{notice}</span>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* 1. قسم المظهر والشاشة والوضع الداكن */}
        <div className={`rounded-2xl p-4 border transition-colors duration-300 space-y-3 ${theme.cardBg}`}>
          <div className="flex items-center justify-between">
            <h3 className={`font-bold text-xs ${isDarkMode ? 'text-[#C9A961]' : 'text-[#0B3D2E]'} flex items-center gap-1.5`}>
              {isDarkMode ? <Moon className="w-4 h-4 text-[#C9A961]" /> : <Sun className="w-4 h-4 text-amber-500" />}
              <span>المظهر والشاشة (Dark Mode)</span>
            </h3>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                isDarkMode
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : 'bg-amber-100 text-amber-900 border border-amber-200'
              }`}
            >
              {isDarkMode ? 'الوضع الداكن مفعّل 🌙' : 'الوضع الفاتح مفعّل ☀️'}
            </span>
          </div>

          <div className={`flex items-center justify-between p-3 rounded-xl border transition-colors ${theme.secondaryBox}`}>
            <div className="flex items-center gap-2.5">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                  isDarkMode ? 'bg-emerald-950 text-[#C9A961]' : 'bg-amber-50 text-amber-600'
                }`}
              >
                {isDarkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </div>
              <div>
                <p className={`font-bold text-xs ${theme.textPrimary}`}>الوضع الداكن المريح للعين</p>
                <p className={`text-[10px] ${theme.textSecondary}`}>
                  تقليل إجهاد العين أثناء العمل ليلاً وتوفير طاقة بطارية الهاتف
                </p>
              </div>
            </div>

            {/* Switch Toggle Button */}
            <button
              type="button"
              onClick={toggleDarkMode}
              className={`w-14 h-7 rounded-full transition-colors relative p-0.5 focus:outline-none ${
                isDarkMode ? 'bg-[#0B3D2E] border border-[#C9A961]/40' : 'bg-gray-300'
              }`}
              title="تبديل الوضع الداكن / الفاتح"
            >
              <div
                className={`w-6 h-6 rounded-full bg-white shadow-md flex items-center justify-center transition-transform duration-300 ${
                  isDarkMode ? 'translate-x-[-1.75rem] bg-[#FAF8F3]' : 'translate-x-0'
                }`}
              >
                {isDarkMode ? (
                  <Moon className="w-3.5 h-3.5 text-[#0B3D2E]" />
                ) : (
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                )}
              </div>
            </button>
          </div>

          {/* Quick Dual Switch Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => setDarkMode(false)}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition ${
                !isDarkMode
                  ? 'bg-[#0B3D2E] text-white border-[#0B3D2E] shadow-xs'
                  : 'bg-[#141F1A] text-gray-300 border-emerald-900/40 hover:bg-[#1a2822]'
              }`}
            >
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>الوضع الفاتح (نهاري)</span>
            </button>

            <button
              type="button"
              onClick={() => setDarkMode(true)}
              className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition ${
                isDarkMode
                  ? 'bg-[#C9A961] text-[#0B3D2E] border-[#C9A961] font-black shadow-xs'
                  : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
              <span>الوضع الداكن (ليلي)</span>
            </button>
          </div>
        </div>

        {/* 2. قسم بيانات المتجر */}
        <div className={`rounded-2xl p-4 border transition-colors duration-300 ${theme.cardBg}`}>
          <h3 className={`font-bold text-xs ${isDarkMode ? 'text-[#C9A961]' : 'text-[#0B3D2E]'} flex items-center gap-1.5 mb-3`}>
            <Store className="w-4 h-4 text-[#C9A961]" />
            <span>بيانات المتجر</span>
          </h3>

          <form onSubmit={handleUpdateStoreProfile} className="space-y-3">
            <div>
              <label className={`block text-[11px] font-bold mb-1 ${theme.textSecondary}`}>اسم البقالة:</label>
              <input
                type="text"
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className={`w-full rounded-xl px-3 py-2 text-xs border ${theme.inputBg}`}
                required
              />
            </div>
            <div>
              <label className={`block text-[11px] font-bold mb-1 ${theme.textSecondary}`}>المحافظة:</label>
              <input
                type="text"
                value={governorate}
                onChange={(e) => setGovernorate(e.target.value)}
                className={`w-full rounded-xl px-3 py-2 text-xs border ${theme.inputBg}`}
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-[#0B3D2E] hover:bg-[#06231A] text-white py-2 rounded-xl text-xs font-bold transition shadow-xs"
            >
              حفظ التعديلات
            </button>
          </form>
        </div>

        {/* 3. قسم الأمان والحماية */}
        <div className={`rounded-2xl p-4 border transition-colors duration-300 space-y-3 ${theme.cardBg}`}>
          <h3 className={`font-bold text-xs ${isDarkMode ? 'text-[#C9A961]' : 'text-[#0B3D2E]'} flex items-center gap-1.5`}>
            <Shield className="w-4 h-4 text-[#C9A961]" />
            <span>الأمان والحماية</span>
          </h3>

          {/* Biometrics Toggle */}
          <div className={`flex items-center justify-between p-2.5 rounded-xl border ${theme.secondaryBox}`}>
            <div className="flex items-center gap-2">
              <Fingerprint className="w-5 h-5 text-[#C9A961]" />
              <div>
                <p className={`font-bold text-xs ${theme.textPrimary}`}>تفعيل البصمة (Biometric)</p>
                <p className={`text-[10px] ${theme.textSecondary}`}>حماية الدخول بالبصمة البيومترية</p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleBiometricToggle}
              className={`w-12 h-6 rounded-full transition-colors relative ${
                biometricEnabled ? 'bg-[#0B3D2E]' : 'bg-gray-400'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-transform ${
                  biometricEnabled ? 'right-6' : 'right-0.5'
                }`}
              />
            </button>
          </div>

          {/* Change PIN button */}
          <div className={`flex items-center justify-between p-2.5 rounded-xl border ${theme.secondaryBox}`}>
            <div className="flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-[#C9A961]" />
              <div>
                <p className={`font-bold text-xs ${theme.textPrimary}`}>رمز الأمان السري (PIN)</p>
                <p className={`text-[10px] ${theme.textSecondary} font-mono`}>الرمز الحالي: {pin.replace(/./g, '•')}</p>
              </div>
            </div>
            <button
              onClick={() => setShowPinModal(true)}
              className={`text-xs border font-bold px-3 py-1.5 rounded-lg transition ${
                isDarkMode ? 'bg-[#141F1A] border-emerald-800 text-gray-200 hover:bg-[#1a2822]' : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
              }`}
            >
              تغيير
            </button>
          </div>
        </div>

        {/* 4. قسم النسخ الاحتياطي والاسترجاع */}
        <div className={`rounded-2xl p-4 border transition-colors duration-300 space-y-3 ${theme.cardBg}`}>
          <h3 className={`font-bold text-xs ${isDarkMode ? 'text-[#C9A961]' : 'text-[#0B3D2E]'} flex items-center gap-1.5`}>
            <Download className="w-4 h-4 text-[#C9A961]" />
            <span>النسخ الاحتياطي لقاعدة البيانات</span>
          </h3>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleBackupToEmail}
              className={`p-3 border rounded-xl text-center flex flex-col items-center transition ${
                isDarkMode ? 'bg-emerald-950/40 hover:bg-emerald-950/70 border-emerald-800/80' : 'bg-emerald-50 hover:bg-emerald-100 border-emerald-300'
              }`}
            >
              <Mail className="w-5 h-5 text-[#C9A961] mb-1" />
              <span className={`font-bold text-xs ${theme.textPrimary}`}>نسخ للبريد الإلكتروني</span>
              <span className={`text-[9px] ${theme.textSecondary}`}>ضغط ملف SQLite وإرساله</span>
            </button>

            <label
              className={`p-3 border rounded-xl text-center flex flex-col items-center cursor-pointer transition ${
                isDarkMode ? 'bg-blue-950/40 hover:bg-blue-950/70 border-blue-800/80' : 'bg-blue-50 hover:bg-blue-100 border-blue-300'
              }`}
            >
              <Upload className="w-5 h-5 text-blue-400 mb-1" />
              <span className={`font-bold text-xs ${theme.textPrimary}`}>استرجاع من ملف</span>
              <span className={`text-[9px] ${theme.textSecondary}`}>رفع .zip أو .json</span>
              <input
                type="file"
                accept=".zip,.json"
                onChange={handleRestoreFile}
                className="hidden"
              />
            </label>
          </div>

          <button
            onClick={() => {
              if (confirm('هل أنت متأكد من إعادة ضبط بيانات البقالة إلى العينات الافتراضية؟')) {
                db.resetToDefaults();
                loadSettings();
                setNotice('تمت استعادة البيانات الافتراضية للمتجر');
              }
            }}
            className="w-full text-center text-[11px] text-gray-400 hover:text-red-400 font-semibold py-1 flex items-center justify-center gap-1 transition"
          >
            <RefreshCw className="w-3 h-3" />
            <span>استعادة البيانات الافتراضية التجريبية</span>
          </button>
        </div>

        {/* 5. قسم الاشتراك والدعم الفني */}
        <div className={`rounded-2xl p-4 border transition-colors duration-300 space-y-3 ${theme.cardBg}`}>
          <div className="flex justify-between items-center">
            <h3 className={`font-bold text-xs ${isDarkMode ? 'text-[#C9A961]' : 'text-[#0B3D2E]'}`}>حالة الاشتراك والترخيص</h3>
            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                subStatus.isExpired
                  ? 'bg-red-950 text-red-300 border border-red-800'
                  : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
              }`}
            >
              {subStatus.isExpired ? 'منتهي' : `نشط (متبقي ${subStatus.daysRemaining} يوم)`}
            </span>
          </div>

          <p className={`text-xs ${theme.textSecondary}`}>
            تاريخ انتهاء الاشتراك: <span className={`font-bold ${theme.textPrimary}`}>{expiryDate}</span>
          </p>

          <div className={`p-3 rounded-xl border space-y-2 ${theme.secondaryBox}`}>
            <p className={`text-[11px] font-bold ${theme.textSecondary}`}>تجديد الاشتراك والتواصل المباشر:</p>
            <div className="grid grid-cols-3 gap-1.5">
              <a
                href={`tel:${SUPPORT_PHONE}`}
                className="p-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-center text-xs font-bold flex items-center justify-center gap-1 transition"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>اتصال</span>
              </a>

              <a
                href={`https://api.whatsapp.com/send?phone=${SUPPORT_PHONE}&text=${encodeURIComponent(
                  'أهلاً، أريد تجديد اشتراك تطبيق إدارة البقالة للمتجر: ' + storeName
                )}`}
                target="_blank"
                rel="noreferrer"
                className="p-2 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-center text-xs font-bold flex items-center justify-center gap-1 transition"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>واتساب</span>
              </a>

              <a
                href={`sms:${SUPPORT_PHONE}?body=${encodeURIComponent('طلب تجديد اشتراك تطبيق البقالة')}`}
                className="p-2 bg-gray-800 hover:bg-black text-white rounded-xl text-center text-xs font-bold flex items-center justify-center gap-1 transition"
              >
                <Send className="w-3.5 h-3.5" />
                <span>SMS</span>
              </a>
            </div>
            <p className="text-[10px] text-gray-500 text-center font-mono">{SUPPORT_PHONE}</p>
          </div>
        </div>
      </div>

      {/* Biometric Scan Modal */}
      <BiometricPromptModal
        isOpen={showBiometricModal}
        onClose={() => setShowBiometricModal(false)}
        onSuccess={handleBiometricSuccess}
      />

      {/* Change PIN Modal */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className={`rounded-3xl w-full max-w-xs p-5 shadow-2xl border border-[#C9A961] space-y-3 ${isDarkMode ? 'bg-[#18221E] text-white' : 'bg-[#FAF8F3] text-gray-900'}`}>
            <h3 className="font-bold text-sm text-[#C9A961]">تغيير رمز الأمان (PIN)</h3>
            <form onSubmit={handleChangePin} className="space-y-3">
              <input
                type="password"
                maxLength={4}
                placeholder="أدخل 4 أرقام جديدة"
                value={newPinInput}
                onChange={(e) => setNewPinInput(e.target.value)}
                autoFocus
                className={`w-full text-center text-lg font-mono tracking-widest border rounded-xl p-2.5 ${theme.inputBg}`}
                required
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#0B3D2E] text-white py-2 rounded-xl text-xs font-bold hover:bg-[#06231A]"
                >
                  حفظ الرمز
                </button>
                <button
                  type="button"
                  onClick={() => setShowPinModal(false)}
                  className={`px-3 py-2 border rounded-xl text-xs font-bold transition ${isDarkMode ? 'border-emerald-800 text-gray-300 hover:bg-[#121B17]' : 'border-gray-300 text-gray-700 hover:bg-gray-100'}`}
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
