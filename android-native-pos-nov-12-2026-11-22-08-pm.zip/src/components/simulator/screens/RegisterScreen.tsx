/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ArrowRight, Store, User, Phone, Lock, MapPin, KeyRound, Check } from 'lucide-react';
import { db } from '../../../db/sqlite-simulation.ts';
import { useTheme } from '../../../context/ThemeContext.tsx';

interface RegisterScreenProps {
  onNavigate: (screen: string, params?: Record<string, unknown>) => void;
}

const GOVERNORATES = ['صنعاء', 'عدن', 'تعز', 'إب', 'حضرموت', 'الحديدة', 'ذمار'];
const DISTRICTS = ['معين', 'السبعين', 'التحرير', 'كريتر', 'المنصورة', 'القاهرة', 'المظفر'];
const NEIGHBORHOODS = ['شارع الرباط', 'حي الأصبحي', 'حدة', 'المعلا', 'حافة القاضي', 'المسبح', 'شارع جمال'];

export const RegisterScreen: React.FC<RegisterScreenProps> = ({ onNavigate }) => {
  const { theme, isDarkMode } = useTheme();
  const [storeName, setStoreName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [governorate, setGovernorate] = useState(GOVERNORATES[0]);
  const [district, setDistrict] = useState(DISTRICTS[0]);
  const [neighborhood, setNeighborhood] = useState(NEIGHBORHOODS[0]);

  const [error, setError] = useState<string | null>(null);
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinCode, setPinCode] = useState('');
  const [registeredStoreId, setRegisteredStoreId] = useState<number | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!storeName.trim() || !ownerName.trim() || !phone.trim() || !password.trim()) {
      setError('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    if (db.isPhoneRegistered(phone)) {
      setError('رقم الهاتف مسجل مسبقاً! يرجى تسجيل الدخول بدلاً من ذلك');
      return;
    }

    const newUser = db.registerUser({
      store_name: storeName.trim(),
      owner_name: ownerName.trim(),
      phone: phone.trim(),
      password: password.trim(),
      governorate,
      district,
      neighborhood,
      pin_code: '1234',
    });

    setRegisteredStoreId(newUser.id);
    setShowPinModal(true);
  };

  const handleSavePinAndFinish = () => {
    const finalPin = pinCode.trim().length >= 4 ? pinCode.trim() : '1234';
    if (registeredStoreId) {
      db.updateUserProfile(registeredStoreId, { pin_code: finalPin });
      db.saveSharedPreferences({
        user_id: registeredStoreId,
        store_id: registeredStoreId,
        status: 'active',
        current_pin: finalPin,
      });
      onNavigate('dashboard', {
        storeName,
        isSuspended: false,
      });
    }
  };

  return (
    <div className={`flex-1 flex flex-col ${theme.screenBg} ${theme.textPrimary}`}>
      {/* Top Header */}
      <div className="bg-[#0B3D2E] text-white p-4 flex items-center justify-between shadow-md border-b border-[#C9A961]/30">
        <button
          onClick={() => onNavigate('login')}
          className="p-1 hover:bg-white/10 rounded-full"
        >
          <ArrowRight className="w-5 h-5" />
        </button>
        <h2 className="font-bold text-sm">إنشاء حساب بقالة جديد</h2>
        <div className="w-5" />
      </div>

      <div className="flex-1 overflow-y-auto p-5">
        <div className={`${
          isDarkMode
            ? 'bg-emerald-950/60 border-emerald-800 text-emerald-200'
            : 'bg-emerald-50 border-emerald-200 text-emerald-900'
        } border p-3 rounded-2xl mb-4 text-xs font-semibold`}>
          🎁 احصل على ترخيص اشتراك تجريبي مجاني لمدة 60 يوماً بكافة الصلاحيات!
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className={`block text-xs font-bold mb-1 ${theme.textPrimary}`}>اسم البقالة / المتجر:</label>
            <div className="relative">
              <input
                type="text"
                placeholder="مثال: بقالة النور الحديثة"
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className={`w-full ${theme.inputBg} border ${theme.borderColor} ${theme.textPrimary} rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#C9A961]`}
                required
              />
              <Store className="w-4 h-4 text-[#C9A961] absolute left-3 top-2.5" />
            </div>
          </div>

          <div>
            <label className={`block text-xs font-bold mb-1 ${theme.textPrimary}`}>اسم المالك:</label>
            <div className="relative">
              <input
                type="text"
                placeholder="اسم المالك الكامل"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className={`w-full ${theme.inputBg} border ${theme.borderColor} ${theme.textPrimary} rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#C9A961]`}
                required
              />
              <User className="w-4 h-4 text-[#C9A961] absolute left-3 top-2.5" />
            </div>
          </div>

          <div>
            <label className={`block text-xs font-bold mb-1 ${theme.textPrimary}`}>رقم الهاتف:</label>
            <div className="relative">
              <input
                type="tel"
                placeholder="مثال: 775001122"
                dir="ltr"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className={`w-full text-right ${theme.inputBg} border ${theme.borderColor} ${theme.textPrimary} rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#C9A961]`}
                required
              />
              <Phone className="w-4 h-4 text-[#C9A961] absolute left-3 top-2.5" />
            </div>
          </div>

          <div>
            <label className={`block text-xs font-bold mb-1 ${theme.textPrimary}`}>كلمة المرور:</label>
            <div className="relative">
              <input
                type="password"
                placeholder="كلمة مرور الدخول"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`w-full ${theme.inputBg} border ${theme.borderColor} ${theme.textPrimary} rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-[#C9A961]`}
                required
              />
              <Lock className="w-4 h-4 text-[#C9A961] absolute left-3 top-2.5" />
            </div>
          </div>

          {/* Location Spinners */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            <div>
              <label className={`block text-[11px] font-bold mb-1 ${theme.textPrimary}`}>المحافظة:</label>
              <select
                value={governorate}
                onChange={(e) => setGovernorate(e.target.value)}
                className={`w-full ${theme.inputBg} border ${theme.borderColor} ${theme.textPrimary} rounded-xl p-2 text-xs`}
              >
                {GOVERNORATES.map((g) => (
                  <option key={g} value={g} className={isDarkMode ? 'bg-[#15201C] text-gray-100' : 'bg-white text-gray-900'}>{g}</option>
                ))}
              </select>
            </div>

            <div>
              <label className={`block text-[11px] font-bold mb-1 ${theme.textPrimary}`}>المديرية:</label>
              <select
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className={`w-full ${theme.inputBg} border ${theme.borderColor} ${theme.textPrimary} rounded-xl p-2 text-xs`}
              >
                {DISTRICTS.map((d) => (
                  <option key={d} value={d} className={isDarkMode ? 'bg-[#15201C] text-gray-100' : 'bg-white text-gray-900'}>{d}</option>
                ))}
              </select>
            </div>

            <div>
              <label className={`block text-[11px] font-bold mb-1 ${theme.textPrimary}`}>الحارة:</label>
              <select
                value={neighborhood}
                onChange={(e) => setNeighborhood(e.target.value)}
                className={`w-full ${theme.inputBg} border ${theme.borderColor} ${theme.textPrimary} rounded-xl p-2 text-xs`}
              >
                {NEIGHBORHOODS.map((n) => (
                  <option key={n} value={n} className={isDarkMode ? 'bg-[#15201C] text-gray-100' : 'bg-white text-gray-900'}>{n}</option>
                ))}
              </select>
            </div>
          </div>

          {error && (
            <p className="text-xs text-[#8B2E2E] font-bold bg-red-50 p-2 rounded-xl">
              {error}
            </p>
          )}

          <button
            type="submit"
            className="w-full bg-[#0B3D2E] text-white py-3 rounded-xl font-bold text-xs hover:bg-[#06231A] active:scale-98 transition shadow-md mt-4 border border-[#C9A961]/40"
          >
            إنشاء الحساب ومتابعة إعداد PIN
          </button>
        </form>
      </div>

      {/* PIN Creation Modal */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className={`${theme.cardBg} rounded-3xl w-full max-w-xs p-5 shadow-2xl border ${isDarkMode ? 'border-emerald-800' : 'border-[#C9A961]'} text-center`}>
            <div className={`w-12 h-12 ${isDarkMode ? 'bg-emerald-950/80 text-emerald-300' : 'bg-emerald-100 text-[#0B3D2E]'} rounded-full flex items-center justify-center mx-auto mb-3`}>
              <KeyRound className="w-6 h-6 text-[#C9A961]" />
            </div>
            <h3 className={`font-bold text-sm ${theme.textPrimary}`}>إنشاء رمز الأمان (PIN)</h3>
            <p className={`text-xs ${theme.textSecondary} mt-1 mb-4`}>
              أدخل رمزاً مكوناً من 4 أرقام لتأكيد العمليات الحساسة
            </p>

            <input
              type="password"
              maxLength={4}
              placeholder="1234"
              value={pinCode}
              onChange={(e) => setPinCode(e.target.value)}
              className={`w-full text-center tracking-widest text-lg font-mono border ${theme.borderColor} rounded-xl p-2.5 ${theme.inputBg} ${theme.textPrimary} mb-4 focus:outline-none focus:border-[#C9A961]`}
            />

            <button
              onClick={handleSavePinAndFinish}
              className="w-full bg-[#0B3D2E] text-white py-2.5 rounded-xl font-bold text-xs hover:bg-[#06231A] border border-[#C9A961]/40"
            >
              حفظ ودخول الشاشة الرئيسية
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
