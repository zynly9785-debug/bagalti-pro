/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Camera, X, Scan, CheckCircle2, AlertCircle } from 'lucide-react';
import { db } from '../../db/sqlite-simulation.ts';

interface BarcodeScannerModalProps {
  storeId: number;
  isOpen: boolean;
  onClose: () => void;
  onBarcodeDetected: (barcode: string) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  storeId,
  isOpen,
  onClose,
  onBarcodeDetected,
}) => {
  const [manualCode, setManualCode] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const activeProducts = db.getProducts(storeId);

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setManualCode('');
      setCameraError(null);
    }
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          setCameraActive(true);
        }
      } else {
        setCameraError('الكاميرا غير مدعومة في هذا المتصفح');
      }
    } catch {
      setCameraError('تعذر الوصول للكاميرا، يرجى اختيار باركود من القائمة السريعة أدناه');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-[#FAF8F3] rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl border border-[#C9A961]/40 flex flex-col">
        {/* Header */}
        <div className="bg-[#0B3D2E] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Scan className="w-5 h-5 text-[#C9A961]" />
            <h3 className="font-bold text-sm">ماسح الباركود (ZXing Scanner)</h3>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1 text-white/80 hover:text-white rounded-full hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Camera / Scanner Frame */}
        <div className="p-4 space-y-3">
          <div className="relative w-full h-48 bg-black rounded-2xl overflow-hidden flex items-center justify-center border-2 border-dashed border-[#C9A961]">
            {cameraActive ? (
              <video ref={videoRef} className="w-full h-full object-cover" />
            ) : (
              <div className="text-center p-4">
                <Camera className="w-10 h-10 text-gray-500 mx-auto mb-2 animate-pulse" />
                <p className="text-xs text-gray-400">الكاميرا في وضع الاستعداد أو غير مفعلة</p>
                <button
                  onClick={startCamera}
                  className="mt-2 text-xs bg-[#C9A961] text-[#0B3D2E] font-bold px-3 py-1.5 rounded-lg hover:bg-[#e0be75]"
                >
                  تشغيل كاميرا الجهاز
                </button>
              </div>
            )}

            {/* Red Laser Barcode line animation */}
            <div className="absolute inset-x-4 top-1/2 -translate-y-1/2 h-0.5 bg-red-500 shadow-[0_0_10px_red] animate-pulse" />
          </div>

          {cameraError && (
            <div className="flex items-start gap-1.5 p-2 bg-amber-50 text-amber-800 text-xs rounded-xl border border-amber-200">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
              <span>{cameraError}</span>
            </div>
          )}

          {/* Quick Barcode Selector for instant simulation */}
          <div>
            <label className="text-xs font-bold text-[#0B3D2E] block mb-1.5">
              أصناف البقالة المتوفرة (انقر للمسح الفوري):
            </label>
            <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
              {activeProducts.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    stopCamera();
                    onBarcodeDetected(p.barcode);
                  }}
                  className="w-full text-right p-2 rounded-xl bg-white border border-gray-200 hover:border-[#0B3D2E] hover:bg-emerald-50/50 flex items-center justify-between text-xs transition"
                >
                  <div className="truncate">
                    <p className="font-semibold text-gray-800 truncate">{p.name}</p>
                    <p className="text-[10px] text-gray-500 font-mono">{p.barcode}</p>
                  </div>
                  <span className="text-[#C9A961] font-bold font-mono shrink-0 ml-2">
                    {p.sale_price} ر.ي
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Manual Input */}
          <div className="pt-2 border-t border-gray-200 flex gap-2">
            <input
              type="text"
              placeholder="أو أدخل رقم الباركود يدوياً..."
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && manualCode.trim()) {
                  stopCamera();
                  onBarcodeDetected(manualCode.trim());
                }
              }}
              className="flex-1 text-xs border border-gray-300 rounded-xl px-3 py-2 bg-white focus:outline-none focus:border-[#0B3D2E]"
            />
            <button
              disabled={!manualCode.trim()}
              onClick={() => {
                stopCamera();
                onBarcodeDetected(manualCode.trim());
              }}
              className="bg-[#0B3D2E] text-white text-xs px-3 py-2 rounded-xl font-bold disabled:opacity-50"
            >
              تحقق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
