/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ShieldCheck, KeyRound, HelpCircle, X, AlertTriangle } from 'lucide-react';
import { verifyOwnerSecret, verifyOwnerRecoveryAnswer } from '../../utils/pureLogic.ts';

interface OwnerSecretDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const OwnerSecretDialog: React.FC<OwnerSecretDialogProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [showForgotRecovery, setShowForgotRecovery] = useState(false);
  const [recoveryAnswer, setRecoveryAnswer] = useState('');
  const [recoverySuccessNotice, setRecoverySuccessNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleVerifyPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyOwnerSecret(password)) {
      setError(null);
      onClose();
      onSuccess();
    } else {
      setError('كلمة مرور المالك غير صحيحة!');
    }
  };

  const handleVerifyRecovery = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyOwnerRecoveryAnswer(recoveryAnswer)) {
      setRecoverySuccessNotice('تم التحقق بنجاح! كلمة المرور هي: zain774923');
      setTimeout(() => {
        onClose();
        onSuccess();
      }, 1500);
    } else {
      setError('إجابة غير صحيحة! تأكد من كتابة: زينون');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-[#FAF8F3] rounded-3xl w-full max-w-sm overflow-hidden shadow-2xl border-2 border-[#C9A961] animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="bg-[#0B3D2E] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#C9A961]" />
            <h3 className="font-bold text-sm">بوابة المالك الإدارية السرية</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-white/80 hover:text-white rounded-full hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="flex items-center gap-2 text-xs text-emerald-900 bg-emerald-50 p-2.5 rounded-xl border border-emerald-200">
            <KeyRound className="w-4 h-4 text-[#C9A961] shrink-0" />
            <span>تم تفعيل الباب السري بنجاح بعد 10 نقرات متتالية!</span>
          </div>

          {!showForgotRecovery ? (
            <form onSubmit={handleVerifyPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  أدخل كلمة مرور المالك الإدارية:
                </label>
                <input
                  type="password"
                  placeholder="كلمة المرور..."
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError(null);
                  }}
                  autoFocus
                  className="w-full text-center tracking-widest text-sm font-mono border border-gray-300 rounded-xl p-3 bg-white focus:outline-none focus:border-[#0B3D2E]"
                />
              </div>

              {error && (
                <div className="text-xs text-[#8B2E2E] flex items-center gap-1 font-semibold">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{error}</span>
                </div>
              )}

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#0B3D2E] text-white py-2.5 rounded-xl font-bold text-xs hover:bg-[#06231A] transition shadow-md"
                >
                  دخول لوحة المالك
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setError(null);
                    setShowForgotRecovery(true);
                  }}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2.5 rounded-xl font-bold text-xs transition"
                >
                  نسيت الرمز؟
                </button>
              </div>

              <p className="text-[11px] text-gray-400 text-center font-mono">
                (تلميح المالك للاختبار: zain774923)
              </p>
            </form>
          ) : (
            <form onSubmit={handleVerifyRecovery} className="space-y-4">
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900">
                <div className="flex items-center gap-1.5 font-bold mb-1">
                  <HelpCircle className="w-4 h-4 text-amber-700" />
                  <span>سؤال التحقق الأمني:</span>
                </div>
                <p className="font-semibold text-sm">من أنت؟</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  إجابة التحقق:
                </label>
                <input
                  type="text"
                  placeholder="اكتب الإجابة..."
                  value={recoveryAnswer}
                  onChange={(e) => {
                    setRecoveryAnswer(e.target.value);
                    setError(null);
                  }}
                  autoFocus
                  className="w-full text-center text-sm font-semibold border border-gray-300 rounded-xl p-3 bg-white focus:outline-none focus:border-[#0B3D2E]"
                />
              </div>

              {error && (
                <div className="text-xs text-[#8B2E2E] flex items-center gap-1 font-semibold">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{error}</span>
                </div>
              )}

              {recoverySuccessNotice && (
                <div className="text-xs text-emerald-700 bg-emerald-50 p-2 rounded-lg font-bold">
                  {recoverySuccessNotice}
                </div>
              )}

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-[#C9A961] text-[#0B3D2E] py-2.5 rounded-xl font-bold text-xs hover:bg-[#e0be75] transition shadow-md"
                >
                  تحقق ودخول
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowForgotRecovery(false);
                    setError(null);
                  }}
                  className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2.5 rounded-xl font-bold text-xs"
                >
                  رجوع
                </button>
              </div>

              <p className="text-[11px] text-gray-400 text-center font-mono">
                (تلميح الإجابة السرية: زينون)
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
