package com.baqalatypro.pos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
